import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-MJA7T467.js";
import "./chunk-YGMCJW2Q.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
