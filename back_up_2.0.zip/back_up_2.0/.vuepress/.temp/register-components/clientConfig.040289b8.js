import { defineAsyncComponent } from 'vue'

export default {
  enhance: ({ app }) => {    
  },
}
