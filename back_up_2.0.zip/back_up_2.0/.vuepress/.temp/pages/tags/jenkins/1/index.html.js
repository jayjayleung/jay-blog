export const data = {
  "key": "v-03ff7db4",
  "path": "/tags/jenkins/1/",
  "title": "",
  "lang": "en-US",
  "frontmatter": {
    "layout": "Categories"
  },
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": null
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
