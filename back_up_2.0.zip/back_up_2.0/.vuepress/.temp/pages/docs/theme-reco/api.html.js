export const data = {
  "key": "v-acdd9360",
  "path": "/docs/theme-reco/api.html",
  "title": "api",
  "lang": "en-US",
  "frontmatter": {
    "title": "api",
    "date": "2020/05/29"
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "docs/theme-reco/api.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
