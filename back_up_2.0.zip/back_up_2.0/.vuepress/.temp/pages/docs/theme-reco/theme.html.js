export const data = {
  "key": "v-65959fc1",
  "path": "/docs/theme-reco/theme.html",
  "title": "theme",
  "lang": "en-US",
  "frontmatter": {
    "title": "theme",
    "date": "2020/05/27"
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "docs/theme-reco/theme.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
