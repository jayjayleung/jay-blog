export const data = {
  "key": "v-456cc6d6",
  "path": "/docs/theme-reco/plugin.html",
  "title": "plugin",
  "lang": "en-US",
  "frontmatter": {
    "title": "plugin",
    "date": "2020/05/28"
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "docs/theme-reco/plugin.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
