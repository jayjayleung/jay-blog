export const data = {
  "key": "v-8daa1a0e",
  "path": "/",
  "title": "",
  "lang": "en-US",
  "frontmatter": {
    "home": true,
    "modules": [
      "bannerBrand",
      "Blog",
      "MdContent",
      "Footer"
    ],
    "banner": {
      "heroText": "jayjay's blog",
      "tagline": "good good study, day day up",
      "heroImage": "/logo.png",
      "heroImageStyle": {
        "maxWidth": "200px",
        "margin": "0 auto 2rem"
      },
      "bgImage": "/bg.svg",
      "bgImageStyle": {
        "height": "450px"
      }
    },
    "bannerBrand": {
      "bannerBrand": null,
      "heroImage": "/logo.png",
      "heroImageStyle": {
        "maxWidth": "200px",
        "width": "100%",
        "display": "block",
        "margin": "0 auto 2rem",
        "borderRadius": "1rem"
      },
      "bgImage": "/bg.svg",
      "heroText": "jayjay's blog",
      "tagline": "good good study, day day up"
    },
    "blog": {
      "socialLinks": [
        {
          "icon": "BrandGithub",
          "link": "https://github.com/recoluan"
        },
        {
          "icon": "BallBowling",
          "link": "https://juejin.cn/user/1583723129876158"
        }
      ]
    },
    "footer": {
      "record": "粤ICP备20012943号",
      "recordLink": "https://beian.miit.gov.cn/",
      "startYear": 2022
    }
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672692000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "JayJay",
        "email": "55223868+jayjayleung@users.noreply.github.com",
        "commits": 1
      },
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "README.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
