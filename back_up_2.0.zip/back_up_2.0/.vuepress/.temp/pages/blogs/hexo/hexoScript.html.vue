<template><div><h1 id="hexo常用命令" tabindex="-1"><a class="header-anchor" href="#hexo常用命令" aria-hidden="true">#</a> <a href="https://www.cnblogs.com/lzf1996/p/5220585.html" target="_blank" rel="noopener noreferrer">Hexo常用命令<ExternalLinkIcon/></a></h1>
<h2 id="hexo" tabindex="-1"><a class="header-anchor" href="#hexo" aria-hidden="true">#</a> hexo</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">npm</span> <span class="token function">install</span> hexo -g <span class="token comment">#安装  </span>
<span class="token function">npm</span> update hexo -g <span class="token comment">#升级  </span>
hexo init <span class="token comment">#初始化</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="简写" tabindex="-1"><a class="header-anchor" href="#简写" aria-hidden="true">#</a> 简写</h2>
<p><code v-pre>hexo n &quot;我的博客&quot;</code> == <code v-pre>hexo new &quot;我的博客&quot;</code> #新建文章
<code v-pre>hexo p</code> == <code v-pre>hexo publish</code>
<code v-pre>hexo g</code> == <code v-pre>hexo generate</code>#生成
<code v-pre>hexo s</code> == <code v-pre>hexo server</code> #启动服务预览
<code v-pre>hexo d</code> == <code v-pre>hexo deploy</code>#部署</p>
<h2 id="服务器" tabindex="-1"><a class="header-anchor" href="#服务器" aria-hidden="true">#</a> 服务器</h2>
<p><code v-pre>hexo server</code> #Hexo 会监视文件变动并自动更新，您无须重启服务器。
<code v-pre>hexo server -s</code> #静态模式
<code v-pre>hexo server -p 5000</code> #更改端口
<code v-pre>hexo server -i 192.168.1.1</code> #自定义 IP</p>
<p><code v-pre>hexo clean</code> #清除缓存 网页正常情况下可以忽略此条命令
<code v-pre>hexo g</code> #生成静态网页
<code v-pre>hexo d</code> #开始部署</p>
<h3 id="监视文件变动" tabindex="-1"><a class="header-anchor" href="#监视文件变动" aria-hidden="true">#</a> 监视文件变动</h3>
<p><code v-pre>hexo generate</code> #使用 Hexo 生成静态文件快速而且简单
<code v-pre>hexo generate --watch</code> #监视文件变动</p>
<h3 id="完成后部署" tabindex="-1"><a class="header-anchor" href="#完成后部署" aria-hidden="true">#</a> 完成后部署</h3>
<blockquote>
<p>两个命令的作用是相同的
<code v-pre>hexo generate --deploy</code>
<code v-pre>hexo deploy --generate</code></p>
</blockquote>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo deploy -g`
`hexo server -g
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="草稿" tabindex="-1"><a class="header-anchor" href="#草稿" aria-hidden="true">#</a> 草稿</h2>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo publish [layout] &lt;title>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h2 id="模版" tabindex="-1"><a class="header-anchor" href="#模版" aria-hidden="true">#</a> 模版</h2>
<p><code v-pre>hexo new &quot;postName&quot;</code> #新建文章
<code v-pre>hexo new page &quot;pageName&quot;</code> #新建页面
<code v-pre>hexo generate</code> #生成静态页面至public目录
<code v-pre>hexo server</code> #开启预览访问端口（默认端口4000，'ctrl + c'关闭server）
<code v-pre>hexo deploy</code> #将.deploy目录部署到GitHub</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo new [layout] &lt;title>`
`hexo new photo "My Gallery"`
`hexo new "Hello World" --lang tw
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><table>
<thead>
<tr>
<th>变量</th>
<th>描述</th>
</tr>
</thead>
<tbody>
<tr>
<td>layout</td>
<td>布局</td>
</tr>
<tr>
<td>title</td>
<td>标题</td>
</tr>
<tr>
<td>date</td>
<td>文件建立日期</td>
</tr>
</tbody>
</table>
<div class="language-yaml ext-yml line-numbers-mode"><pre v-pre class="language-yaml"><code><span class="token key atrule">title</span><span class="token punctuation">:</span> 使用Hexo搭建个人博客
<span class="token key atrule">layout</span><span class="token punctuation">:</span> post
<span class="token key atrule">date</span><span class="token punctuation">:</span> <span class="token datetime number">2014-03-03 19:07:43</span>
<span class="token key atrule">comments</span><span class="token punctuation">:</span> <span class="token boolean important">true</span>
<span class="token key atrule">categories</span><span class="token punctuation">:</span> Blog
<span class="token key atrule">tags</span><span class="token punctuation">:</span> <span class="token punctuation">[</span>Hexo<span class="token punctuation">]</span>
<span class="token key atrule">keywords</span><span class="token punctuation">:</span> Hexo<span class="token punctuation">,</span> Blog
<span class="token key atrule">description</span><span class="token punctuation">:</span> 生命在于折腾，又把博客折腾到Hexo了。给Hexo点赞。
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="模版-scaffold" tabindex="-1"><a class="header-anchor" href="#模版-scaffold" aria-hidden="true">#</a> 模版（Scaffold）</h2>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo new photo "My Gallery"
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><table>
<thead>
<tr>
<th>变量</th>
<th>描述</th>
</tr>
</thead>
<tbody>
<tr>
<td>layout</td>
<td>布局</td>
</tr>
<tr>
<td>title</td>
<td>标题</td>
</tr>
<tr>
<td>date</td>
<td>文件建立日期</td>
</tr>
</tbody>
</table>
<h2 id="设置文章摘要" tabindex="-1"><a class="header-anchor" href="#设置文章摘要" aria-hidden="true">#</a> 设置文章摘要</h2>
<div class="language-xml ext-xml line-numbers-mode"><pre v-pre class="language-xml"><code>以上是文章摘要 <span class="token comment">&lt;!--more--></span> 以下是余下全文 
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h2 id="写作" tabindex="-1"><a class="header-anchor" href="#写作" aria-hidden="true">#</a> 写作</h2>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo new page &lt;title>`
`hexo new post &lt;title>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><table>
<thead>
<tr>
<th>变量</th>
<th>描述</th>
</tr>
</thead>
<tbody>
<tr>
<td>:title</td>
<td>标题</td>
</tr>
<tr>
<td>:year</td>
<td>建立的年份（4 位数）</td>
</tr>
<tr>
<td>:month</td>
<td>建立的月份（2 位数）</td>
</tr>
<tr>
<td>:i_month</td>
<td>建立的月份（去掉开头的零）</td>
</tr>
<tr>
<td>:day</td>
<td>建立的日期（2 位数）</td>
</tr>
<tr>
<td>:i_day</td>
<td>建立的日期（去掉开头的零）</td>
</tr>
</tbody>
</table>
<h3 id="推送到服务器上" tabindex="-1"><a class="header-anchor" href="#推送到服务器上" aria-hidden="true">#</a> 推送到服务器上</h3>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>hexo n` #写文章
`hexo g` #生成
`hexo d` #部署 #可与`hexo g`合并为 `hexo d -g
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="报错" tabindex="-1"><a class="header-anchor" href="#报错" aria-hidden="true">#</a> 报错</h2>
<h3 id="_1-找不到git部署" tabindex="-1"><a class="header-anchor" href="#_1-找不到git部署" aria-hidden="true">#</a> 1.找不到git部署</h3>
<div class="language-vbnet ext-vbnet line-numbers-mode"><pre v-pre class="language-vbnet"><code><span class="token keyword">ERROR</span> Deployer <span class="token keyword">not</span> found<span class="token punctuation">:</span> git
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>解决方法</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>npm install hexo-deployer-git --save
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="_3-部署类型设置git" tabindex="-1"><a class="header-anchor" href="#_3-部署类型设置git" aria-hidden="true">#</a> 3.部署类型设置git</h3>
<p>hexo 3.0 部署类型不再是<code v-pre>github</code>，<code v-pre>_config.yml</code> 中修改</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token comment"># Deployment</span>
<span class="token comment">## Docs: http://hexo.io/docs/deployment.html</span>
deploy:
  type: <span class="token function">git</span>
  repository: git@***.github.com:***/***.github.io.git
  branch: master
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="_4-xcodebuild" tabindex="-1"><a class="header-anchor" href="#_4-xcodebuild" aria-hidden="true">#</a> 4. xcodebuild</h3>
<p>xcode-select: error: tool 'xcodebuild' requires Xcode, but active developer directory '/Library/Developer/CommandLineTools' is a command line tools instance</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>npm install bcrypt
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="_5-rss不显示" tabindex="-1"><a class="header-anchor" href="#_5-rss不显示" aria-hidden="true">#</a> 5. RSS不显示</h3>
<h4 id="安装rss插件" tabindex="-1"><a class="header-anchor" href="#安装rss插件" aria-hidden="true">#</a> 安装RSS插件</h4>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>npm install hexo-generator-feed --save
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h4 id="开启rss功能" tabindex="-1"><a class="header-anchor" href="#开启rss功能" aria-hidden="true">#</a> 开启RSS功能</h4>
<p>编辑hexo/_config.yml，添加如下代码：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>rss: /atom.xml <span class="token comment">#rss地址  默认即可</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h4 id="开启评论" tabindex="-1"><a class="header-anchor" href="#开启评论" aria-hidden="true">#</a> 开启评论</h4>
<p>在当前使用主题的目录下修改_config.yml配置文件</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code> 查找：duoshuo   然后将enable:true
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div></div></template>
