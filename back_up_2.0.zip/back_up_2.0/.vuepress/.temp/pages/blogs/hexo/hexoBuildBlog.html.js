export const data = {
  "key": "v-caf8793e",
  "path": "/blogs/hexo/hexoBuildBlog.html",
  "title": "hexo搭建博客",
  "lang": "en-US",
  "frontmatter": {
    "title": "hexo搭建博客",
    "date": "2021-11-11T18:22:00.000Z",
    "tags": [
      "hexo"
    ],
    "categories": [
      "hexo"
    ]
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "前言：",
      "slug": "前言",
      "children": []
    },
    {
      "level": 2,
      "title": "什么是Hexo ?",
      "slug": "什么是hexo",
      "children": []
    },
    {
      "level": 2,
      "title": "搭建步骤",
      "slug": "搭建步骤",
      "children": []
    },
    {
      "level": 2,
      "title": "获得个人网站域名",
      "slug": "获得个人网站域名",
      "children": []
    },
    {
      "level": 2,
      "title": "GitHub创建个人仓库",
      "slug": "github创建个人仓库",
      "children": []
    },
    {
      "level": 2,
      "title": "安装Git",
      "slug": "安装git",
      "children": []
    },
    {
      "level": 2,
      "title": "安装Node.js",
      "slug": "安装node-js",
      "children": []
    },
    {
      "level": 2,
      "title": "安装Hexo",
      "slug": "安装hexo",
      "children": []
    },
    {
      "level": 2,
      "title": "推送网站",
      "slug": "推送网站",
      "children": []
    },
    {
      "level": 2,
      "title": "绑定域名",
      "slug": "绑定域名",
      "children": []
    },
    {
      "level": 2,
      "title": "更换主题",
      "slug": "更换主题",
      "children": []
    },
    {
      "level": 2,
      "title": "发布文章",
      "slug": "发布文章",
      "children": []
    },
    {
      "level": 2,
      "title": "寻找图床",
      "slug": "寻找图床",
      "children": []
    },
    {
      "level": 2,
      "title": "个性化设置",
      "slug": "个性化设置",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "blogs/hexo/hexoBuildBlog.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
