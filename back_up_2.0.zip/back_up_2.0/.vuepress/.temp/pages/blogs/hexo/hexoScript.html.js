export const data = {
  "key": "v-754aeb94",
  "path": "/blogs/hexo/hexoScript.html",
  "title": "Hexo常用命令",
  "lang": "en-US",
  "frontmatter": {
    "title": "Hexo常用命令",
    "date": "2022-04-26T18:22:00.000Z",
    "tags": [
      "hexo"
    ],
    "categories": [
      "hexo"
    ]
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "hexo",
      "slug": "hexo",
      "children": []
    },
    {
      "level": 2,
      "title": "简写",
      "slug": "简写",
      "children": []
    },
    {
      "level": 2,
      "title": "服务器",
      "slug": "服务器",
      "children": [
        {
          "level": 3,
          "title": "监视文件变动",
          "slug": "监视文件变动",
          "children": []
        },
        {
          "level": 3,
          "title": "完成后部署",
          "slug": "完成后部署",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "草稿",
      "slug": "草稿",
      "children": []
    },
    {
      "level": 2,
      "title": "模版",
      "slug": "模版",
      "children": []
    },
    {
      "level": 2,
      "title": "模版（Scaffold）",
      "slug": "模版-scaffold",
      "children": []
    },
    {
      "level": 2,
      "title": "设置文章摘要",
      "slug": "设置文章摘要",
      "children": []
    },
    {
      "level": 2,
      "title": "写作",
      "slug": "写作",
      "children": [
        {
          "level": 3,
          "title": "推送到服务器上",
          "slug": "推送到服务器上",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "报错",
      "slug": "报错",
      "children": [
        {
          "level": 3,
          "title": "1.找不到git部署",
          "slug": "_1-找不到git部署",
          "children": []
        },
        {
          "level": 3,
          "title": "3.部署类型设置git",
          "slug": "_3-部署类型设置git",
          "children": []
        },
        {
          "level": 3,
          "title": "4. xcodebuild",
          "slug": "_4-xcodebuild",
          "children": []
        },
        {
          "level": 3,
          "title": "5. RSS不显示",
          "slug": "_5-rss不显示",
          "children": []
        }
      ]
    }
  ],
  "git": {},
  "filePathRelative": "blogs/hexo/hexoScript.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
