export const data = {
  "key": "v-bcab6b12",
  "path": "/blogs/linux/GitLab%E4%BB%A3%E7%A0%81%E6%89%98%E7%AE%A1%E6%9C%8D%E5%8A%A1%E5%99%A8%E5%AE%89%E8%A3%85.html",
  "title": "GitLab代码托管服务器安装",
  "lang": "en-US",
  "frontmatter": {
    "title": "GitLab代码托管服务器安装",
    "date": "2022-05-19T00:00:00.000Z",
    "tags": [
      "gitlab"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/gitlab"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "GitLab简介",
      "slug": "gitlab简介",
      "children": []
    },
    {
      "level": 2,
      "title": "Gitlab安装",
      "slug": "gitlab安装",
      "children": []
    },
    {
      "level": 2,
      "title": "gitlab 常用命令",
      "slug": "gitlab-常用命令",
      "children": []
    },
    {
      "level": 2,
      "title": "Gitlab添加组、创建用户、创建项目",
      "slug": "gitlab添加组、创建用户、创建项目",
      "children": [
        {
          "level": 3,
          "title": "创建组",
          "slug": "创建组",
          "children": []
        },
        {
          "level": 3,
          "title": "创建用户",
          "slug": "创建用户",
          "children": []
        },
        {
          "level": 3,
          "title": "将用户添加到组中",
          "slug": "将用户添加到组中",
          "children": []
        },
        {
          "level": 3,
          "title": "在用户组中创建项目",
          "slug": "在用户组中创建项目",
          "children": []
        }
      ]
    }
  ],
  "git": {},
  "filePathRelative": "blogs/linux/GitLab代码托管服务器安装.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
