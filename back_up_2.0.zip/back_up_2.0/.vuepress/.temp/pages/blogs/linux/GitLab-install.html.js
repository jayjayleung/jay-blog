export const data = {
  "key": "v-38646e04",
  "path": "/blogs/linux/GitLab-install.html",
  "title": "GitLab代码托管服务器安装",
  "lang": "en-US",
  "frontmatter": {
    "title": "GitLab代码托管服务器安装",
    "date": "2022-05-19T00:00:00.000Z",
    "tags": [
      "gitlab"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/gitlab"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "GitLab简介",
      "slug": "gitlab简介",
      "children": []
    },
    {
      "level": 2,
      "title": "Gitlab安装",
      "slug": "gitlab安装",
      "children": []
    },
    {
      "level": 2,
      "title": "gitlab 常用命令",
      "slug": "gitlab-常用命令",
      "children": []
    },
    {
      "level": 2,
      "title": "Gitlab添加组、创建用户、创建项目",
      "slug": "gitlab添加组、创建用户、创建项目",
      "children": [
        {
          "level": 3,
          "title": "创建组",
          "slug": "创建组",
          "children": []
        },
        {
          "level": 3,
          "title": "创建用户",
          "slug": "创建用户",
          "children": []
        },
        {
          "level": 3,
          "title": "将用户添加到组中",
          "slug": "将用户添加到组中",
          "children": []
        },
        {
          "level": 3,
          "title": "在用户组中创建项目",
          "slug": "在用户组中创建项目",
          "children": []
        }
      ]
    }
  ],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/GitLab-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
