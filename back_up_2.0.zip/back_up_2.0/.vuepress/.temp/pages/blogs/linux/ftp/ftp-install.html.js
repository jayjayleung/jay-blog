export const data = {
  "key": "v-20b1cca8",
  "path": "/blogs/linux/ftp/ftp-install.html",
  "title": "Linux 使用 Vsftpd 搭建 FTP 服务",
  "lang": "en-US",
  "frontmatter": {
    "title": "Linux 使用 Vsftpd 搭建 FTP 服务",
    "date": "2022-01-27T17:03:05.000Z",
    "tags": [
      "ftp"
    ],
    "categories": [
      "linux"
    ]
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "FTP 的两种模式",
      "slug": "ftp-的两种模式",
      "children": [
        {
          "level": 3,
          "title": "主动模式",
          "slug": "主动模式",
          "children": []
        },
        {
          "level": 3,
          "title": "被动模式",
          "slug": "被动模式",
          "children": []
        },
        {
          "level": 3,
          "title": "两种模式比较",
          "slug": "两种模式比较",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "安装 Vsftpd",
      "slug": "安装-vsftpd",
      "children": []
    },
    {
      "level": 2,
      "title": "配置 Vsftpd",
      "slug": "配置-vsftpd",
      "children": []
    },
    {
      "level": 2,
      "title": "防火墙配置",
      "slug": "防火墙配置",
      "children": []
    },
    {
      "level": 2,
      "title": "文件目录说明",
      "slug": "文件目录说明",
      "children": []
    },
    {
      "level": 2,
      "title": "vsftpd.conf 配置说明",
      "slug": "vsftpd-conf-配置说明",
      "children": []
    },
    {
      "level": 2,
      "title": "常用命令",
      "slug": "常用命令",
      "children": []
    }
  ],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/ftp/ftp-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
