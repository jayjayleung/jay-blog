<template><div><h1 id="在docker下载nginx镜像" tabindex="-1"><a class="header-anchor" href="#在docker下载nginx镜像" aria-hidden="true">#</a> 在Docker下载Nginx镜像</h1>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> pull nginx:latest

拉取完成查看：docker images
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="创建挂载目录" tabindex="-1"><a class="header-anchor" href="#创建挂载目录" aria-hidden="true">#</a> 创建挂载目录</h1>
<p>先在主机创建工作文件夹，为了挂载配置和静态文件的访问使用</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">mkdir</span> -p /home/nginx/<span class="token punctuation">{</span>conf,conf.d,html,logs<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h1 id="编写nginx-conf配置文件-并放在文件夹中" tabindex="-1"><a class="header-anchor" href="#编写nginx-conf配置文件-并放在文件夹中" aria-hidden="true">#</a> 编写<code v-pre>nginx.conf</code>配置文件，并放在文件夹中</h1>
<div class="language-lua ext-lua line-numbers-mode"><pre v-pre class="language-lua"><code><span class="token function">server</span> <span class="token punctuation">{</span>
    listen       <span class="token number">80</span><span class="token punctuation">;</span>
    listen  <span class="token punctuation">[</span><span class="token punctuation">::</span><span class="token punctuation">]</span><span class="token punctuation">:</span><span class="token number">80</span><span class="token punctuation">;</span>
    server_name  localhost<span class="token punctuation">;</span>

    <span class="token operator">#</span>access_log  <span class="token operator">/</span>var<span class="token operator">/</span>log<span class="token operator">/</span>nginx<span class="token operator">/</span>host<span class="token punctuation">.</span>access<span class="token punctuation">.</span>log  main<span class="token punctuation">;</span>

    location <span class="token operator">/</span> <span class="token punctuation">{</span>
        root   <span class="token operator">/</span>usr<span class="token operator">/</span>share<span class="token operator">/</span>nginx<span class="token operator">/</span>html<span class="token operator">/</span>fgo<span class="token operator">-</span>images<span class="token punctuation">;</span> 
        index  index<span class="token punctuation">.</span>html index<span class="token punctuation">.</span>htm<span class="token punctuation">;</span>
        try_files $uri $uri<span class="token operator">/</span> <span class="token operator">/</span>index<span class="token punctuation">.</span>html<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>

    <span class="token operator">#</span>error_page  <span class="token number">404</span>              <span class="token operator">/</span><span class="token number">404.</span>html<span class="token punctuation">;</span>

    <span class="token operator">#</span> redirect server error pages to the static page <span class="token operator">/</span>50x<span class="token punctuation">.</span>html
    <span class="token operator">#</span>
    error_page   <span class="token number">500</span> <span class="token number">502</span> <span class="token number">503</span> <span class="token number">504</span>  <span class="token operator">/</span>50x<span class="token punctuation">.</span>html<span class="token punctuation">;</span>
    location <span class="token operator">=</span> <span class="token operator">/</span>50x<span class="token punctuation">.</span><span class="token function">html</span> <span class="token punctuation">{</span>
        root   <span class="token operator">/</span>usr<span class="token operator">/</span>share<span class="token operator">/</span>nginx<span class="token operator">/</span>html<span class="token punctuation">;</span>
    <span class="token punctuation">}</span>

    <span class="token operator">#</span> proxy the PHP scripts to Apache listening on <span class="token number">127.0</span><span class="token number">.0</span><span class="token number">.1</span><span class="token punctuation">:</span><span class="token number">80</span>
    <span class="token operator">#</span>
    <span class="token operator">#</span>location <span class="token operator">~</span> \<span class="token punctuation">.</span>php$ <span class="token punctuation">{</span>
    <span class="token operator">#</span>    proxy_pass   http<span class="token punctuation">:</span><span class="token operator">//</span><span class="token number">127.0</span><span class="token number">.0</span><span class="token number">.1</span><span class="token punctuation">;</span>
    <span class="token operator">#</span><span class="token punctuation">}</span>

    <span class="token operator">#</span> pass the PHP scripts to FastCGI server listening on <span class="token number">127.0</span><span class="token number">.0</span><span class="token number">.1</span><span class="token punctuation">:</span><span class="token number">9000</span>
    <span class="token operator">#</span>
    <span class="token operator">#</span>location <span class="token operator">~</span> \<span class="token punctuation">.</span>php$ <span class="token punctuation">{</span>
    <span class="token operator">#</span>    root           html<span class="token punctuation">;</span>
    <span class="token operator">#</span>    fastcgi_pass   <span class="token number">127.0</span><span class="token number">.0</span><span class="token number">.1</span><span class="token punctuation">:</span><span class="token number">9000</span><span class="token punctuation">;</span>
    <span class="token operator">#</span>    fastcgi_index  index<span class="token punctuation">.</span>php<span class="token punctuation">;</span>
    <span class="token operator">#</span>    fastcgi_param  SCRIPT_FILENAME  <span class="token operator">/</span>scripts$fastcgi_script_name<span class="token punctuation">;</span>
    <span class="token operator">#</span>    include        fastcgi_params<span class="token punctuation">;</span>
    <span class="token operator">#</span><span class="token punctuation">}</span>

    <span class="token operator">#</span> deny access to <span class="token punctuation">.</span>htaccess files<span class="token punctuation">,</span> <span class="token keyword">if</span> Apache's document root
    <span class="token operator">#</span> concurs with nginx's one
    <span class="token operator">#</span>
    <span class="token operator">#</span>location <span class="token operator">~</span> <span class="token operator">/</span>\<span class="token punctuation">.</span><span class="token function">ht</span> <span class="token punctuation">{</span>
    <span class="token operator">#</span>    deny  all<span class="token punctuation">;</span>
    <span class="token operator">#</span><span class="token punctuation">}</span>
<span class="token punctuation">}</span>


</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>也可以启动nginx容器来复制</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token comment">#启动一个容器</span>
 <span class="token function">docker</span> run -d --name nginx nginx
<span class="token comment"># 查看 容器 获取容器ID 或直接使用名字</span>
 <span class="token function">docker</span> container <span class="token function">ls</span>
<span class="token comment"># 在当前目录下创建目录：conf </span>
 <span class="token function">mkdir</span> conf
<span class="token comment"># 拷贝容器内 Nginx 默认配置文件到本地当前目录下的 conf 目录（$PWD 当前全路径）</span>
<span class="token function">docker</span> <span class="token function">cp</span> nginx:/etc/nginx/nginx.conf <span class="token environment constant">$PWD</span>/conf
<span class="token function">docker</span> <span class="token function">cp</span> nginx:/etc/nginx/conf.d <span class="token environment constant">$PWD</span>/conf

<span class="token comment"># 停止容器</span>
 <span class="token function">docker</span> container stop nginx
<span class="token comment"># 删除容器</span>
 <span class="token function">docker</span> container <span class="token function">rm</span> nginx

<span class="token comment"># 在当前目录下创建目录：html 放静态文件</span>
 <span class="token function">mkdir</span> html
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="启动容器" tabindex="-1"><a class="header-anchor" href="#启动容器" aria-hidden="true">#</a> 启动容器</h1>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run --privileged<span class="token operator">=</span>true -d -p <span class="token number">80</span>:80 -p <span class="token number">443</span>:443 --name nginx  -v /home/nginx/html:/usr/share/nginx/html  -v /home/nginx/conf.d:/etc/nginx/conf.d -v /home/nginx/logs:/var/log/nginx  nginx  
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>下面这个命令用不了，挂载<code v-pre>ngxinx.conf</code>文件失败，找了很多方法都解决不了，只能用上面的命令启动</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run --privileged<span class="token operator">=</span>true -d -p <span class="token number">80</span>:80 -p <span class="token number">443</span>:443 --name nginx -v /home/nginx/nginx.conf:/etc/nginx/nginx.conf -v /home/nginx/html:/usr/share/nginx/html  -v /home/nginx/conf.d:/etc/nginx/conf.d -v /home/nginx/logs:/var/log/nginx  nginx  
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h1 id="查看启动的容器" tabindex="-1"><a class="header-anchor" href="#查看启动的容器" aria-hidden="true">#</a> 查看启动的容器</h1>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token function">ps</span> 
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>访问80端口查看是否成功，如果能出来页面就成功了</p>
</div></template>
