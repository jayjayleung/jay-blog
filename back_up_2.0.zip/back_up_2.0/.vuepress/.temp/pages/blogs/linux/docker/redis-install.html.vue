<template><div><h1 id="一、找到一个合适的docker的redis的版本" tabindex="-1"><a class="header-anchor" href="#一、找到一个合适的docker的redis的版本" aria-hidden="true">#</a> 一、找到一个合适的docker的redis的版本</h1>
<p>可以去<a href="https://hub.docker.com/_/redis?tab=tags" target="_blank" rel="noopener noreferrer">docker hub<ExternalLinkIcon/></a>中去找一下</p>
<h1 id="二、使用docker安装redis" tabindex="-1"><a class="header-anchor" href="#二、使用docker安装redis" aria-hidden="true">#</a> 二、使用docker安装redis</h1>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">docker</span> pull redis
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>安装好之后使用<code v-pre>docker images</code>即可查看</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">docker</span> images
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h1 id="三、准备redis的配置文件" tabindex="-1"><a class="header-anchor" href="#三、准备redis的配置文件" aria-hidden="true">#</a> 三、准备redis的配置文件</h1>
<p>因为需要redis的配置文件<code v-pre>redis.conf</code>，这里最好还是去redis的[官方下载][http://download.redis.io/redis-stable/redis.conf]一个redis使用里面的配置文件即可</p>
<p>或者在linux敲</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">wget</span> https://raw.githubusercontent.com/antirez/redis/4.0/redis.conf -O conf/redis.conf
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h1 id="四、配置redis-conf配置文件" tabindex="-1"><a class="header-anchor" href="#四、配置redis-conf配置文件" aria-hidden="true">#</a> 四、配置redis.conf配置文件</h1>
<p><strong>修改<code v-pre>redis.conf</code>配置文件：</strong></p>
<p>主要配置的如下：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token builtin class-name">bind</span> <span class="token number">127.0</span>.0.1 <span class="token comment">#注释掉这部分，使redis可以外部访问</span>
daemonize no<span class="token comment">#用守护线程的方式启动</span>
requirepass 你的密码<span class="token comment">#给redis设置密码</span>
appendonly <span class="token function">yes</span><span class="token comment">#redis持久化　　默认是no</span>
tcp-keepalive <span class="token number">300</span> <span class="token comment">#防止出现远程主机强迫关闭了一个现有的连接的错误 默认是300</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="五、创建本地与docker映射的目录-即本地存放的位置" tabindex="-1"><a class="header-anchor" href="#五、创建本地与docker映射的目录-即本地存放的位置" aria-hidden="true">#</a> 五、创建本地与docker映射的目录，即本地存放的位置</h1>
<p>创建本地存放redis的位置：</p>
<p>可以自定义，因为我的docker的一些配置文件都是存放在<code v-pre>/data</code>目录下面的，所以我依然在<code v-pre>/data</code>目录下创建一个<code v-pre>redis</code>目录，这样是为了方便后期管理</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">mkdir</span> /home/redis
<span class="token function">mkdir</span> /home/redis/data
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>把<code v-pre>配置文件</code>拷贝到刚才创建好的<code v-pre>/home/redis</code>里</p>
<h1 id="六、启动docker-redis" tabindex="-1"><a class="header-anchor" href="#六、启动docker-redis" aria-hidden="true">#</a> 六、启动docker redis</h1>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run -p <span class="token number">6379</span>:6379 --name redis -v /home/redis/redis.conf:/etc/redis/redis.conf  -v /home/redis/data:/data -d redis redis-server /etc/redis/redis.conf --appendonly <span class="token function">yes</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>参数解释：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>-p <span class="token number">6379</span>:6379:把容器内的6379端口映射到宿主机6379端口
-v /home/redis/redis.conf:/etc/redis/redis.conf：把宿主机配置好的redis.conf放到容器内的这个位置中
-v /home/redis/data:/data：把redis持久化的数据在宿主机内显示，做数据备份
redis-server /etc/redis/redis.conf：这个是关键配置，让redis不是无配置启动，而是按照这个redis.conf的配置启动
–appendonly yes：redis启动后数据持久化
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h1 id="七、查看是否启动成功" tabindex="-1"><a class="header-anchor" href="#七、查看是否启动成功" aria-hidden="true">#</a> 七、查看是否启动成功</h1>
<p>是否成功启动：如果有redis就代表成功了</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> <span class="token function">ps</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>查看日志：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> logs redis
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div></div></template>
