<template><div><h1 id="centos-docker-安装" tabindex="-1"><a class="header-anchor" href="#centos-docker-安装" aria-hidden="true">#</a> CentOS Docker 安装</h1>
<p>1、Docker 要求 CentOS 系统的内核版本高于 3.10 ，查看本页面的前提条件来验证你的CentOS 版本是否支持 Docker 。</p>
<p>Docker 支持以下的 64 位 CentOS 版本：</p>
<ul>
<li>CentOS 7</li>
<li>CentOS 8</li>
<li>更高版本...</li>
</ul>
<h2 id="使用官方安装脚本自动安装" tabindex="-1"><a class="header-anchor" href="#使用官方安装脚本自动安装" aria-hidden="true">#</a> 使用官方安装脚本自动安装</h2>
<p>安装命令如下：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">curl</span> -fsSL https://get.docker.com <span class="token operator">|</span> <span class="token function">bash</span> -s <span class="token function">docker</span> --mirror Aliyun
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>也可以使用国内 daocloud 一键安装命令：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">curl</span> -sSL https://get.daocloud.io/docker <span class="token operator">|</span> <span class="token function">sh</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h2 id="手动安装" tabindex="-1"><a class="header-anchor" href="#手动安装" aria-hidden="true">#</a> 手动安装</h2>
<h3 id="卸载旧版本" tabindex="-1"><a class="header-anchor" href="#卸载旧版本" aria-hidden="true">#</a> 卸载旧版本</h3>
<p>较旧的 Docker 版本称为 docker 或 docker-engine 。如果已安装这些程序，请卸载它们以及相关的依赖项。</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum remove <span class="token function">docker</span> <span class="token punctuation">\</span>
                  docker-client <span class="token punctuation">\</span>
                  docker-client-latest <span class="token punctuation">\</span>
                  docker-common <span class="token punctuation">\</span>
                  docker-latest <span class="token punctuation">\</span>
                  docker-latest-logrotate <span class="token punctuation">\</span>
                  docker-logrotate <span class="token punctuation">\</span>
                  docker-engine
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="安装-docker" tabindex="-1"><a class="header-anchor" href="#安装-docker" aria-hidden="true">#</a> 安装 Docker</h3>
<h3 id="使用-docker-仓库进行安装" tabindex="-1"><a class="header-anchor" href="#使用-docker-仓库进行安装" aria-hidden="true">#</a> 使用 Docker 仓库进行安装</h3>
<p>在新主机上首次安装 Docker Engine-Community 之前，需要设置 Docker 仓库。之后，您可以从仓库安装和更新 Docker。</p>
<p><strong>设置仓库</strong></p>
<p>安装所需的软件包。yum-utils 提供了 yum-config-manager ，并且 device mapper 存储驱动程序需要 device-mapper-persistent-data 和 lvm2。</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum <span class="token function">install</span> -y yum-utils device-mapper-persistent-data lvm2
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>使用以下命令来设置稳定的仓库。</p>
<p>使用官方源地址（可能比较慢）</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum-config-manager <span class="token punctuation">\</span>
    --add-repo <span class="token punctuation">\</span>
    https://download.docker.com/linux/centos/docker-ce.repo
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>可以选择国内的一些源地址：</p>
<p>阿里云</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum-config-manager <span class="token punctuation">\</span>
    --add-repo <span class="token punctuation">\</span>
    http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>清华大学源</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum-config-manager <span class="token punctuation">\</span>
    --add-repo <span class="token punctuation">\</span>
    https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/centos/docker-ce.repo
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="安装-docker-engine-community" tabindex="-1"><a class="header-anchor" href="#安装-docker-engine-community" aria-hidden="true">#</a> 安装 Docker Engine-Community</h3>
<p>安装最新版本的 Docker Engine-Community 和 containerd，或者转到下一步安装特定版本：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum <span class="token function">install</span> -y docker-ce docker-ce-cli containerd.io
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>如果提示您接受 GPG 密钥，请选是。</p>
<p><strong>有多个 Docker 仓库吗？</strong></p>
<p>如果启用了多个 Docker 仓库，则在未在 yum install 或 yum update 命令中指定版本的情况下，进行的安装或更新将始终安装最高版本，这可能不适合您的稳定性需求。</p>
<p>Docker 安装完默认未启动。并且已经创建好 docker 用户组，但该用户组下没有用户。</p>
<p><strong>要安装特定版本的 Docker Engine-Community，请在存储库中列出可用版本，然后选择并安装：</strong></p>
<p>1、列出并排序您存储库中可用的版本。此示例按版本号（从高到低）对结果进行排序。</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>yum list docker-ce --showduplicates <span class="token operator">|</span> <span class="token function">sort</span> -r
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>docker-ce.x86_64  <span class="token number">3</span>:18.09.1-3.el7                     docker-ce-stable
docker-ce.x86_64  <span class="token number">3</span>:18.09.0-3.el7                     docker-ce-stable
docker-ce.x86_64  <span class="token number">18.06</span>.1.ce-3.el7                    docker-ce-stable
docker-ce.x86_64  <span class="token number">18.06</span>.0.ce-3.el7                    docker-ce-stable
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>2、通过其完整的软件包名称安装特定版本，该软件包名称是软件包名称（docker-ce）加上版本字符串（第二列），从第一个冒号（:）一直到第一个连字符，并用连字符（-）分隔。例如：docker-ce-18.09.1。</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> yum <span class="token function">install</span> docker-ce-<span class="token operator">&lt;</span>VERSION_STRING<span class="token operator">></span> docker-ce-cli-<span class="token operator">&lt;</span>VERSION_STRING<span class="token operator">></span> containerd.io
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="启动-docker" tabindex="-1"><a class="header-anchor" href="#启动-docker" aria-hidden="true">#</a> 启动 Docker</h3>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> systemctl start <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>加入开机启动</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> systemctl <span class="token builtin class-name">enable</span> <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>通过运行 hello-world 映像来验证是否正确安装了 Docker Engine-Community 。</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">docker</span> run hello-world
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="卸载-docker" tabindex="-1"><a class="header-anchor" href="#卸载-docker" aria-hidden="true">#</a> 卸载 docker</h3>
<p>删除安装包：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>yum remove docker-ce
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>删除镜像、容器、配置文件等内容：</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">rm</span> -rf /var/lib/docker
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h2 id="小知识" tabindex="-1"><a class="header-anchor" href="#小知识" aria-hidden="true">#</a> 小知识</h2>
<h3 id="设置docker容器日志大小-全局设置" tabindex="-1"><a class="header-anchor" href="#设置docker容器日志大小-全局设置" aria-hidden="true">#</a> 设置docker容器日志大小（全局设置）</h3>
<p>每个容器的日志默认都会以 json-file 的格式存储于<code v-pre>/var/lib/docker/containers/&lt;容器id&gt;/&lt;容器id&gt;-json.log</code> 下,容器销毁后<code v-pre>/var/lib/docker/containers/&lt;容器id&gt;/</code>目录会被自动删除，所以容器日志也被一并删除。如果容器一直运行并且一直产生日志，容器日志会导致磁盘空间爆满，解决方法如下：</p>
<p>新建<code v-pre>/etc/docker/daemon.json</code>，若有就不用新建了。添加log-dirver和log-opts参数，如下：</p>
<p>**</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code># vim /etc/docker/daemon.json

{
  "registry-mirrors": ["http://f613ce8f.m.daocloud.io"],
  "log-driver":"json-file",
  "log-opts": {"max-size":"500m", "max-file":"3"}
}
复制代码
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><ul>
<li><code v-pre>max-size=500m</code>，意味着一个容器日志大小上限是500M</li>
<li><code v-pre>max-file=3</code>，意味着一个容器最多有三个日志，分别是：<code v-pre>容器id-json.log、容器id-json.log.1、容器id-json.log.2</code>, 当日志文件的大小达到500m时，自动划分文件保存，最多划分3个文件</li>
<li>这两个参数设置之后说明，一个容器最多保存1500m(3 * 500)日志，超过范围的日志不会被保存，文件中保存的是最新的日志，文件会自动滚动更新。</li>
</ul>
<p>**</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code># 重启docker守护进程
systemctl daemon-reload
# 重启docker
systemctl restart docker
复制代码
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><blockquote>
<p><strong>注意：设置的日志大小，只对新建的容器有效。</strong></p>
</blockquote>
<p>设置完成之后，需要删除容器，并重新启动容器。</p>
<h3 id="修改docker数据目录位置-包含镜像位" tabindex="-1"><a class="header-anchor" href="#修改docker数据目录位置-包含镜像位" aria-hidden="true">#</a> 修改Docker数据⽬录位置，包含镜像位</h3>
<p>docker安装后默认目录是 <code v-pre>/var/lib/docker</code></p>
<p>方法:</p>
<p>在/home 目录下创建目录</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token builtin class-name">cd</span> /home
<span class="token function">mkdir</span> <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>修改docker的systemd的 docker.service的配置文件</p>
<p>不知道 配置文件在哪里可以使用systemd 命令显示一下</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl disable <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl <span class="token builtin class-name">enable</span> <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><blockquote>
<p>Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.</p>
</blockquote>
<p>修改docker.service文件</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">vim</span> /usr/lib/systemd/system/docker.service
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>在里面的EXECStart的后面增加后如下:</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token assign-left variable">ExecStart</span><span class="token operator">=</span>/usr/bin/dockerd --graph /home/docker
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>重新enable 一下docker 服务 重新进行软连接 以及进行一次 daemon-reload</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl disable <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl <span class="token builtin class-name">enable</span> <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl daemon-reload
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>systemctl restart <span class="token function">docker</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div></div></template>
