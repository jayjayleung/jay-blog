<template><div><h1 id="背景" tabindex="-1"><a class="header-anchor" href="#背景" aria-hidden="true">#</a> 背景</h1>
<p>使用Docker容器搭建数据库，可以极为方便的移植到其他环境。本文有两种配置方式，一种是在全部文件数据都在容器内部，一种是挂载到外部配置和数据，这要的好处是打包的容器不会随着使用而越来越大。</p>
<p>这里使用的mysql 5.7.36版本，具体需要哪个版本，在[dockerHub][https://hub.docker.com/]搜索查看</p>
<h1 id="一、挂载在容器内部配置文件和数据" tabindex="-1"><a class="header-anchor" href="#一、挂载在容器内部配置文件和数据" aria-hidden="true">#</a> 一、挂载在容器内部配置文件和数据</h1>
<h2 id="docker拉取最新mysql" tabindex="-1"><a class="header-anchor" href="#docker拉取最新mysql" aria-hidden="true">#</a> docker拉取最新MySQL</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">docker</span> pull mysql:5.7.36
<span class="token function">sudo</span> <span class="token function">docker</span> images //查看是否有镜像
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="启动docker-创建mysql" tabindex="-1"><a class="header-anchor" href="#启动docker-创建mysql" aria-hidden="true">#</a> 启动docker，创建MySQL</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">sudo</span> <span class="token function">docker</span> run --name<span class="token operator">=</span>mysql -it -p <span class="token number">3306</span>:3306 -e <span class="token assign-left variable">MYSQL_ROOT_PASSWORD</span><span class="token operator">=</span><span class="token number">123456</span> -d mysql
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>这里挂载内部文件的就完成了，这种方法最快，但改配置不方便</p>
<h1 id="二、挂载外部配置文件和数据" tabindex="-1"><a class="header-anchor" href="#二、挂载外部配置文件和数据" aria-hidden="true">#</a> 二、挂载外部配置文件和数据</h1>
<h2 id="docker拉取mysql" tabindex="-1"><a class="header-anchor" href="#docker拉取mysql" aria-hidden="true">#</a> docker拉取MySQL</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> pull mysql:5.7.36
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h2 id="创建配置文件" tabindex="-1"><a class="header-anchor" href="#创建配置文件" aria-hidden="true">#</a> 创建配置文件</h2>
<p>可以根据需要设置到合适的目录</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">mkdir</span> -p /home/mysql/conf
<span class="token function">mkdir</span> -p /home/mysql/data
<span class="token function">mkdir</span> -p /home/mysql/logs
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="创建mysql配置文件" tabindex="-1"><a class="header-anchor" href="#创建mysql配置文件" aria-hidden="true">#</a> 创建MySQL配置文件</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">vi</span> /home/mysql/conf/my.cnf
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>复制以下内容，为了解决中文乱码问题</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token punctuation">[</span>mysqld<span class="token punctuation">]</span>
pid-file        <span class="token operator">=</span> /var/run/mysqld/mysqld.pid
socket          <span class="token operator">=</span> /var/run/mysqld/mysqld.sock
datadir         <span class="token operator">=</span> /var/lib/mysql
secure-file-priv<span class="token operator">=</span> NULL
<span class="token comment"># Disabling symbolic-links is recommended to prevent assorted security risks</span>
symbolic-links<span class="token operator">=</span><span class="token number">0</span>
character-set-server<span class="token operator">=</span>utf8 
<span class="token punctuation">[</span>client<span class="token punctuation">]</span>
default-character-set<span class="token operator">=</span>utf8 
<span class="token punctuation">[</span>mysql<span class="token punctuation">]</span>
default-character-set<span class="token operator">=</span>utf8 
<span class="token comment"># Custom config should go here</span>
<span class="token operator">!</span>includedir /etc/mysql/conf.d/
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="运行容器" tabindex="-1"><a class="header-anchor" href="#运行容器" aria-hidden="true">#</a> 运行容器</h2>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code><span class="token function">docker</span> run --restart<span class="token operator">=</span>always -d -v /home/mysql/conf/my.cnf:/etc/mysql/my.cnf -v /home/mysql/logs:/logs -v /home/mysql/data/mysql:/var/lib/mysql  -p <span class="token number">3306</span>:3306 --name mysql -e <span class="token assign-left variable">MYSQL_ROOT_PASSWORD</span><span class="token operator">=</span><span class="token number">123456</span> mysql:5.7.36

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>参数解释</p>
<div class="language-bash ext-sh line-numbers-mode"><pre v-pre class="language-bash"><code>--restart<span class="token operator">=</span>always                                            -<span class="token operator">></span> 开机启动容器,容器异常自动重启
-d                                                          -<span class="token operator">></span> 以守护进程的方式启动容器
-v /home/app/mysql/conf.d/my.cnf:/etc/mysql/my.cnf          -<span class="token operator">></span> 映射配置文件
-v /home/app/mysql/logs:/logs                               -<span class="token operator">></span> 映射日志
-v /home/app/mysql/data/mysql:/var/lib/mysql                -<span class="token operator">></span> 映射数据
-p <span class="token number">3306</span>:3306                                                -<span class="token operator">></span> 绑定宿主机端口
--name mysql                                                -<span class="token operator">></span> 指定容器名称
-e <span class="token assign-left variable">MYSQL_ROOT_PASSWORD</span><span class="token operator">=</span><span class="token number">123456</span>                               -<span class="token operator">></span> 写入配置root密码
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>使用数据连接工具连接(比如Navicat)能连上就表示安装成功了</p>
</div></template>
