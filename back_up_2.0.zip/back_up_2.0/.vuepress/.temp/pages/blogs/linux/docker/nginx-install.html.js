export const data = {
  "key": "v-76722be4",
  "path": "/blogs/linux/docker/nginx-install.html",
  "title": "Docker安装并配置Nginx",
  "lang": "en-US",
  "frontmatter": {
    "title": "Docker安装并配置Nginx",
    "date": "2021-11-14T23:10:08.000Z",
    "tags": [
      "docker"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/docker"
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/docker/nginx-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
