export const data = {
  "key": "v-49d39fe3",
  "path": "/blogs/linux/docker/reids-install.html",
  "title": "Docker安装并配置Redis",
  "lang": "en-US",
  "frontmatter": {
    "title": "Docker安装并配置Redis",
    "date": "2021-11-14T22:33:21.000Z",
    "tags": [
      "docker"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/docker"
  },
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": "blogs/linux/docker/reids-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
