export const data = {
  "key": "v-b84cb0a4",
  "path": "/blogs/linux/docker/docker-install.html",
  "title": "linux安装docker",
  "lang": "en-US",
  "frontmatter": {
    "title": "linux安装docker",
    "date": "2022-04-02T21:11:51.000Z",
    "tags": [
      "docker"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/docker"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "使用官方安装脚本自动安装",
      "slug": "使用官方安装脚本自动安装",
      "children": []
    },
    {
      "level": 2,
      "title": "手动安装",
      "slug": "手动安装",
      "children": [
        {
          "level": 3,
          "title": "卸载旧版本",
          "slug": "卸载旧版本",
          "children": []
        },
        {
          "level": 3,
          "title": "安装 Docker",
          "slug": "安装-docker",
          "children": []
        },
        {
          "level": 3,
          "title": "使用 Docker 仓库进行安装",
          "slug": "使用-docker-仓库进行安装",
          "children": []
        },
        {
          "level": 3,
          "title": "安装 Docker Engine-Community",
          "slug": "安装-docker-engine-community",
          "children": []
        },
        {
          "level": 3,
          "title": "启动 Docker",
          "slug": "启动-docker",
          "children": []
        },
        {
          "level": 3,
          "title": "卸载 docker",
          "slug": "卸载-docker",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "小知识",
      "slug": "小知识",
      "children": [
        {
          "level": 3,
          "title": "设置docker容器日志大小（全局设置）",
          "slug": "设置docker容器日志大小-全局设置",
          "children": []
        },
        {
          "level": 3,
          "title": "修改Docker数据⽬录位置，包含镜像位",
          "slug": "修改docker数据目录位置-包含镜像位",
          "children": []
        }
      ]
    }
  ],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/docker/docker-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
