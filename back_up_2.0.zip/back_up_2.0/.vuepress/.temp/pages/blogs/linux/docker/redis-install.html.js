export const data = {
  "key": "v-b9794466",
  "path": "/blogs/linux/docker/redis-install.html",
  "title": "Docker安装并配置Redis",
  "lang": "en-US",
  "frontmatter": {
    "title": "Docker安装并配置Redis",
    "date": "2021-11-14T22:33:21.000Z",
    "tags": [
      "docker"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/docker"
  },
  "excerpt": "",
  "headers": [],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/docker/redis-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
