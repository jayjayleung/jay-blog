export const data = {
  "key": "v-19f3cbf4",
  "path": "/blogs/linux/docker/mysql-install.html",
  "title": "Docker安装MySQL挂载外部配置文件和数据",
  "lang": "en-US",
  "frontmatter": {
    "title": "Docker安装MySQL挂载外部配置文件和数据",
    "date": "2021-11-14T21:43:43.000Z",
    "tags": [
      "docker"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/docker"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "docker拉取最新MySQL",
      "slug": "docker拉取最新mysql",
      "children": []
    },
    {
      "level": 2,
      "title": "启动docker，创建MySQL",
      "slug": "启动docker-创建mysql",
      "children": []
    },
    {
      "level": 2,
      "title": "docker拉取MySQL",
      "slug": "docker拉取mysql",
      "children": []
    },
    {
      "level": 2,
      "title": "创建配置文件",
      "slug": "创建配置文件",
      "children": []
    },
    {
      "level": 2,
      "title": "创建MySQL配置文件",
      "slug": "创建mysql配置文件",
      "children": []
    },
    {
      "level": 2,
      "title": "运行容器",
      "slug": "运行容器",
      "children": []
    }
  ],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/docker/mysql-install.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
