export const data = {
  "key": "v-a904d8a4",
  "path": "/blogs/linux/jenkins/Jenkins.html",
  "title": "Centos安装Jenkins",
  "lang": "en-US",
  "frontmatter": {
    "title": "Centos安装Jenkins",
    "date": "2022-05-19T00:00:00.000Z",
    "tags": [
      "jenkins"
    ],
    "categories": [
      "linux"
    ],
    "contact": "linux/jenkins"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Jenkins介绍",
      "slug": "jenkins介绍",
      "children": []
    },
    {
      "level": 2,
      "title": "Jenkins的特征",
      "slug": "jenkins的特征",
      "children": []
    },
    {
      "level": 2,
      "title": "Jenkins安装",
      "slug": "jenkins安装",
      "children": [
        {
          "level": 3,
          "title": "yum安装",
          "slug": "yum安装",
          "children": []
        },
        {
          "level": 3,
          "title": "rmp安装(北京外国语大学开源软件镜像站)",
          "slug": "rmp安装-北京外国语大学开源软件镜像站",
          "children": []
        },
        {
          "level": 3,
          "title": "修改jenkins配置",
          "slug": "修改jenkins配置",
          "children": []
        },
        {
          "level": 3,
          "title": "踩坑",
          "slug": "踩坑",
          "children": []
        },
        {
          "level": 3,
          "title": "跳过插件安装",
          "slug": "跳过插件安装",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Jenkins插件管理",
      "slug": "jenkins插件管理",
      "children": [
        {
          "level": 3,
          "title": "修改Jenkins插件下载地址",
          "slug": "修改jenkins插件下载地址",
          "children": []
        },
        {
          "level": 3,
          "title": "下载中文汉化插件",
          "slug": "下载中文汉化插件",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Jenkins用户权限管理",
      "slug": "jenkins用户权限管理",
      "children": [
        {
          "level": 3,
          "title": "创建角色",
          "slug": "创建角色",
          "children": []
        },
        {
          "level": 3,
          "title": "创建用户",
          "slug": "创建用户",
          "children": []
        },
        {
          "level": 3,
          "title": "给用户分配角色",
          "slug": "给用户分配角色",
          "children": []
        },
        {
          "level": 3,
          "title": "创建项目测试权限",
          "slug": "创建项目测试权限",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Jenkins凭证管理",
      "slug": "jenkins凭证管理",
      "children": [
        {
          "level": 3,
          "title": "安装Git插件和Git工具",
          "slug": "安装git插件和git工具",
          "children": []
        },
        {
          "level": 3,
          "title": "用户密码类型",
          "slug": "用户密码类型",
          "children": []
        },
        {
          "level": 3,
          "title": "SSH密钥类型",
          "slug": "ssh密钥类型",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Maven安装和配置",
      "slug": "maven安装和配置",
      "children": [
        {
          "level": 3,
          "title": "安装Maven",
          "slug": "安装maven",
          "children": []
        },
        {
          "level": 3,
          "title": "配置环境变量",
          "slug": "配置环境变量",
          "children": []
        },
        {
          "level": 3,
          "title": "全局工具配置关联JDK和Maven",
          "slug": "全局工具配置关联jdk和maven",
          "children": []
        },
        {
          "level": 3,
          "title": "添加Jenkins全局变量",
          "slug": "添加jenkins全局变量",
          "children": []
        },
        {
          "level": 3,
          "title": "配置本地仓库地址和阿里镜像",
          "slug": "配置本地仓库地址和阿里镜像",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Jenkins构建Maven项目",
      "slug": "jenkins构建maven项目",
      "children": [
        {
          "level": 3,
          "title": "Jenkins构建的项目类型介绍",
          "slug": "jenkins构建的项目类型介绍",
          "children": []
        },
        {
          "level": 3,
          "title": "自由风格项目构建",
          "slug": "自由风格项目构建",
          "children": []
        }
      ]
    }
  ],
  "git": {
    "createdTime": 1656672869000,
    "updatedTime": 1656672869000,
    "contributors": [
      {
        "name": "liangshijie",
        "email": "liangshijie@mrcdevlab.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "blogs/linux/jenkins/Jenkins.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
