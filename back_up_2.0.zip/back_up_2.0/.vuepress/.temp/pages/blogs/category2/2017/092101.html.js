export const data = {
  "key": "v-16458837",
  "path": "/blogs/category2/2017/092101.html",
  "title": "second page in category2",
  "lang": "en-US",
  "frontmatter": {
    "title": "second page in category2",
    "date": "2017/09/21",
    "tags": [
      "tag4"
    ],
    "categories": [
      "category2"
    ]
  },
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": "blogs/category2/2017/092101.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
