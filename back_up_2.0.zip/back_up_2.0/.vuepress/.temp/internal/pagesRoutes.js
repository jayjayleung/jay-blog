import { Vuepress } from '@vuepress/client'

const routeItems = [
  ["v-8daa1a0e","/",{"title":""},["/index.html","/README.md"]],
  ["v-38646e04","/blogs/linux/GitLab-install.html",{"title":"GitLab代码托管服务器安装"},["/blogs/linux/GitLab-install","/blogs/linux/GitLab-install.md"]],
  ["v-94c68b46","/docs/hexo/hexoBuildBlog.html",{"title":"hexo搭建博客"},["/docs/hexo/hexoBuildBlog","/docs/hexo/hexoBuildBlog.md"]],
  ["v-729154ba","/docs/hexo/hexoScript.html",{"title":"Hexo常用命令"},["/docs/hexo/hexoScript","/docs/hexo/hexoScript.md"]],
  ["v-acdd9360","/docs/theme-reco/api.html",{"title":"api"},["/docs/theme-reco/api","/docs/theme-reco/api.md"]],
  ["v-5cd03a29","/docs/theme-reco/home.html",{"title":"theme-reco"},["/docs/theme-reco/home","/docs/theme-reco/home.md"]],
  ["v-456cc6d6","/docs/theme-reco/plugin.html",{"title":"plugin"},["/docs/theme-reco/plugin","/docs/theme-reco/plugin.md"]],
  ["v-65959fc1","/docs/theme-reco/theme.html",{"title":"theme"},["/docs/theme-reco/theme","/docs/theme-reco/theme.md"]],
  ["v-b84cb0a4","/blogs/linux/docker/docker-install.html",{"title":"linux安装docker"},["/blogs/linux/docker/docker-install","/blogs/linux/docker/docker-install.md"]],
  ["v-19f3cbf4","/blogs/linux/docker/mysql-install.html",{"title":"Docker安装MySQL挂载外部配置文件和数据"},["/blogs/linux/docker/mysql-install","/blogs/linux/docker/mysql-install.md"]],
  ["v-76722be4","/blogs/linux/docker/nginx-install.html",{"title":"Docker安装并配置Nginx"},["/blogs/linux/docker/nginx-install","/blogs/linux/docker/nginx-install.md"]],
  ["v-b9794466","/blogs/linux/docker/redis-install.html",{"title":"Docker安装并配置Redis"},["/blogs/linux/docker/redis-install","/blogs/linux/docker/redis-install.md"]],
  ["v-20b1cca8","/blogs/linux/ftp/ftp-install.html",{"title":"Linux 使用 Vsftpd 搭建 FTP 服务"},["/blogs/linux/ftp/ftp-install","/blogs/linux/ftp/ftp-install.md"]],
  ["v-a904d8a4","/blogs/linux/jenkins/Jenkins.html",{"title":"Centos安装Jenkins"},["/blogs/linux/jenkins/Jenkins","/blogs/linux/jenkins/Jenkins.md"]],
  ["v-3706649a","/404.html",{"title":""},["/404"]],
  ["v-1b8fdc13","/categories/linux/1/",{"title":""},["/categories/linux/1/index.html"]],
  ["v-362031c2","/categories/hexo/1/",{"title":""},["/categories/hexo/1/index.html"]],
  ["v-833a9e16","/tags/gitlab/1/",{"title":""},["/tags/gitlab/1/index.html"]],
  ["v-03ff7db4","/tags/jenkins/1/",{"title":""},["/tags/jenkins/1/index.html"]],
  ["v-323946dc","/tags/hexo/1/",{"title":""},["/tags/hexo/1/index.html"]],
  ["v-27c565a0","/tags/docker/1/",{"title":""},["/tags/docker/1/index.html"]],
  ["v-127c67f0","/tags/ftp/1/",{"title":""},["/tags/ftp/1/index.html"]],
  ["v-01560935","/timeline/",{"title":""},["/timeline/index.html"]],
  ["v-03d52fd3","/posts/1/",{"title":""},["/posts/1/index.html"]],
  ["v-03d52ff2","/posts/2/",{"title":""},["/posts/2/index.html"]],
]

export const pagesRoutes = routeItems.reduce(
  (result, [name, path, meta, redirects]) => {
    result.push(
      {
        name,
        path,
        component: Vuepress,
        meta,
      },
      ...redirects.map((item) => ({
        path: item,
        redirect: path,
      }))
    )
    return result
  },
  [
    {
      name: '404',
      path: '/:catchAll(.*)',
      component: Vuepress,
    }
  ]
)
