import { defineAsyncComponent } from 'vue'

export const pagesComponents = {
  // path: /
  "v-8daa1a0e": defineAsyncComponent(() => import(/* webpackChunkName: "v-8daa1a0e" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/index.html.vue")),
  // path: /blogs/linux/GitLab-install.html
  "v-38646e04": defineAsyncComponent(() => import(/* webpackChunkName: "v-38646e04" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/GitLab-install.html.vue")),
  // path: /docs/hexo/hexoBuildBlog.html
  "v-94c68b46": defineAsyncComponent(() => import(/* webpackChunkName: "v-94c68b46" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/hexo/hexoBuildBlog.html.vue")),
  // path: /docs/hexo/hexoScript.html
  "v-729154ba": defineAsyncComponent(() => import(/* webpackChunkName: "v-729154ba" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/hexo/hexoScript.html.vue")),
  // path: /docs/theme-reco/api.html
  "v-acdd9360": defineAsyncComponent(() => import(/* webpackChunkName: "v-acdd9360" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/theme-reco/api.html.vue")),
  // path: /docs/theme-reco/home.html
  "v-5cd03a29": defineAsyncComponent(() => import(/* webpackChunkName: "v-5cd03a29" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/theme-reco/home.html.vue")),
  // path: /docs/theme-reco/plugin.html
  "v-456cc6d6": defineAsyncComponent(() => import(/* webpackChunkName: "v-456cc6d6" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/theme-reco/plugin.html.vue")),
  // path: /docs/theme-reco/theme.html
  "v-65959fc1": defineAsyncComponent(() => import(/* webpackChunkName: "v-65959fc1" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/docs/theme-reco/theme.html.vue")),
  // path: /blogs/linux/docker/docker-install.html
  "v-b84cb0a4": defineAsyncComponent(() => import(/* webpackChunkName: "v-b84cb0a4" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/docker/docker-install.html.vue")),
  // path: /blogs/linux/docker/mysql-install.html
  "v-19f3cbf4": defineAsyncComponent(() => import(/* webpackChunkName: "v-19f3cbf4" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/docker/mysql-install.html.vue")),
  // path: /blogs/linux/docker/nginx-install.html
  "v-76722be4": defineAsyncComponent(() => import(/* webpackChunkName: "v-76722be4" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/docker/nginx-install.html.vue")),
  // path: /blogs/linux/docker/redis-install.html
  "v-b9794466": defineAsyncComponent(() => import(/* webpackChunkName: "v-b9794466" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/docker/redis-install.html.vue")),
  // path: /blogs/linux/ftp/ftp-install.html
  "v-20b1cca8": defineAsyncComponent(() => import(/* webpackChunkName: "v-20b1cca8" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/ftp/ftp-install.html.vue")),
  // path: /blogs/linux/jenkins/Jenkins.html
  "v-a904d8a4": defineAsyncComponent(() => import(/* webpackChunkName: "v-a904d8a4" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/blogs/linux/jenkins/Jenkins.html.vue")),
  // path: /404.html
  "v-3706649a": defineAsyncComponent(() => import(/* webpackChunkName: "v-3706649a" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/404.html.vue")),
  // path: /categories/linux/1/
  "v-1b8fdc13": defineAsyncComponent(() => import(/* webpackChunkName: "v-1b8fdc13" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/categories/linux/1/index.html.vue")),
  // path: /categories/hexo/1/
  "v-362031c2": defineAsyncComponent(() => import(/* webpackChunkName: "v-362031c2" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/categories/hexo/1/index.html.vue")),
  // path: /tags/gitlab/1/
  "v-833a9e16": defineAsyncComponent(() => import(/* webpackChunkName: "v-833a9e16" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/tags/gitlab/1/index.html.vue")),
  // path: /tags/jenkins/1/
  "v-03ff7db4": defineAsyncComponent(() => import(/* webpackChunkName: "v-03ff7db4" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/tags/jenkins/1/index.html.vue")),
  // path: /tags/hexo/1/
  "v-323946dc": defineAsyncComponent(() => import(/* webpackChunkName: "v-323946dc" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/tags/hexo/1/index.html.vue")),
  // path: /tags/docker/1/
  "v-27c565a0": defineAsyncComponent(() => import(/* webpackChunkName: "v-27c565a0" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/tags/docker/1/index.html.vue")),
  // path: /tags/ftp/1/
  "v-127c67f0": defineAsyncComponent(() => import(/* webpackChunkName: "v-127c67f0" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/tags/ftp/1/index.html.vue")),
  // path: /timeline/
  "v-01560935": defineAsyncComponent(() => import(/* webpackChunkName: "v-01560935" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/timeline/index.html.vue")),
  // path: /posts/1/
  "v-03d52fd3": defineAsyncComponent(() => import(/* webpackChunkName: "v-03d52fd3" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/posts/1/index.html.vue")),
  // path: /posts/2/
  "v-03d52ff2": defineAsyncComponent(() => import(/* webpackChunkName: "v-03d52ff2" */"D:/jayjay/jay-blog/.vuepress/.temp/pages/posts/2/index.html.vue")),
}
