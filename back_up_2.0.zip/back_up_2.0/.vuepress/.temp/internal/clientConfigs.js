import clientConfig0 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import clientConfig1 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-search/lib/client/config.js'
import clientConfig2 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import clientConfig3 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import clientConfig4 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-external-link-icon/lib/client/config.js'
import clientConfig5 from 'D:/jayjay/jay-blog/.vuepress/.temp/register-components/clientConfig.1538a128.js'
import clientConfig6 from 'D:/jayjay/jay-blog/.vuepress/.temp/register-components/clientConfig.040289b8.js'
import clientConfig7 from 'D:/jayjay/jay-blog/node_modules/@vuepress/plugin-back-to-top/lib/client/config.js'
import clientConfig8 from 'D:/jayjay/jay-blog/node_modules/@vuepress-reco/vuepress-plugin-bulletin-popover/lib/client/config.js'
import clientConfig9 from 'D:/jayjay/jay-blog/node_modules/@vuepress-reco/vuepress-plugin-comments/lib/client/config.js'
import clientConfig10 from 'D:/jayjay/jay-blog/node_modules/@vuepress-reco/vuepress-plugin-page/lib/client/config.js'
import clientConfig11 from 'D:/jayjay/jay-blog/node_modules/@vuepress-reco/style-default/lib/client/config.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
]
