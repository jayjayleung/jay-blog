export const searchIndex = [
  {
    "title": "",
    "headers": [],
    "path": "/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "GitLab代码托管服务器安装",
    "headers": [
      {
        "level": 2,
        "title": "GitLab简介",
        "slug": "gitlab简介",
        "children": []
      },
      {
        "level": 2,
        "title": "Gitlab安装",
        "slug": "gitlab安装",
        "children": []
      },
      {
        "level": 2,
        "title": "gitlab 常用命令",
        "slug": "gitlab-常用命令",
        "children": []
      },
      {
        "level": 2,
        "title": "Gitlab添加组、创建用户、创建项目",
        "slug": "gitlab添加组、创建用户、创建项目",
        "children": [
          {
            "level": 3,
            "title": "创建组",
            "slug": "创建组",
            "children": []
          },
          {
            "level": 3,
            "title": "创建用户",
            "slug": "创建用户",
            "children": []
          },
          {
            "level": 3,
            "title": "将用户添加到组中",
            "slug": "将用户添加到组中",
            "children": []
          },
          {
            "level": 3,
            "title": "在用户组中创建项目",
            "slug": "在用户组中创建项目",
            "children": []
          }
        ]
      }
    ],
    "path": "/blogs/linux/GitLab-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "hexo搭建博客",
    "headers": [
      {
        "level": 2,
        "title": "前言：",
        "slug": "前言",
        "children": []
      },
      {
        "level": 2,
        "title": "什么是Hexo ?",
        "slug": "什么是hexo",
        "children": []
      },
      {
        "level": 2,
        "title": "搭建步骤",
        "slug": "搭建步骤",
        "children": []
      },
      {
        "level": 2,
        "title": "获得个人网站域名",
        "slug": "获得个人网站域名",
        "children": []
      },
      {
        "level": 2,
        "title": "GitHub创建个人仓库",
        "slug": "github创建个人仓库",
        "children": []
      },
      {
        "level": 2,
        "title": "安装Git",
        "slug": "安装git",
        "children": []
      },
      {
        "level": 2,
        "title": "安装Node.js",
        "slug": "安装node-js",
        "children": []
      },
      {
        "level": 2,
        "title": "安装Hexo",
        "slug": "安装hexo",
        "children": []
      },
      {
        "level": 2,
        "title": "推送网站",
        "slug": "推送网站",
        "children": []
      },
      {
        "level": 2,
        "title": "绑定域名",
        "slug": "绑定域名",
        "children": []
      },
      {
        "level": 2,
        "title": "更换主题",
        "slug": "更换主题",
        "children": []
      },
      {
        "level": 2,
        "title": "发布文章",
        "slug": "发布文章",
        "children": []
      },
      {
        "level": 2,
        "title": "寻找图床",
        "slug": "寻找图床",
        "children": []
      },
      {
        "level": 2,
        "title": "个性化设置",
        "slug": "个性化设置",
        "children": []
      }
    ],
    "path": "/docs/hexo/hexoBuildBlog.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Hexo常用命令",
    "headers": [
      {
        "level": 2,
        "title": "hexo",
        "slug": "hexo",
        "children": []
      },
      {
        "level": 2,
        "title": "简写",
        "slug": "简写",
        "children": []
      },
      {
        "level": 2,
        "title": "服务器",
        "slug": "服务器",
        "children": [
          {
            "level": 3,
            "title": "监视文件变动",
            "slug": "监视文件变动",
            "children": []
          },
          {
            "level": 3,
            "title": "完成后部署",
            "slug": "完成后部署",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "草稿",
        "slug": "草稿",
        "children": []
      },
      {
        "level": 2,
        "title": "模版",
        "slug": "模版",
        "children": []
      },
      {
        "level": 2,
        "title": "模版（Scaffold）",
        "slug": "模版-scaffold",
        "children": []
      },
      {
        "level": 2,
        "title": "设置文章摘要",
        "slug": "设置文章摘要",
        "children": []
      },
      {
        "level": 2,
        "title": "写作",
        "slug": "写作",
        "children": [
          {
            "level": 3,
            "title": "推送到服务器上",
            "slug": "推送到服务器上",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "报错",
        "slug": "报错",
        "children": [
          {
            "level": 3,
            "title": "1.找不到git部署",
            "slug": "_1-找不到git部署",
            "children": []
          },
          {
            "level": 3,
            "title": "3.部署类型设置git",
            "slug": "_3-部署类型设置git",
            "children": []
          },
          {
            "level": 3,
            "title": "4. xcodebuild",
            "slug": "_4-xcodebuild",
            "children": []
          },
          {
            "level": 3,
            "title": "5. RSS不显示",
            "slug": "_5-rss不显示",
            "children": []
          }
        ]
      }
    ],
    "path": "/docs/hexo/hexoScript.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "api",
    "headers": [],
    "path": "/docs/theme-reco/api.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "theme-reco",
    "headers": [],
    "path": "/docs/theme-reco/home.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "plugin",
    "headers": [],
    "path": "/docs/theme-reco/plugin.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "theme",
    "headers": [],
    "path": "/docs/theme-reco/theme.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "linux安装docker",
    "headers": [
      {
        "level": 2,
        "title": "使用官方安装脚本自动安装",
        "slug": "使用官方安装脚本自动安装",
        "children": []
      },
      {
        "level": 2,
        "title": "手动安装",
        "slug": "手动安装",
        "children": [
          {
            "level": 3,
            "title": "卸载旧版本",
            "slug": "卸载旧版本",
            "children": []
          },
          {
            "level": 3,
            "title": "安装 Docker",
            "slug": "安装-docker",
            "children": []
          },
          {
            "level": 3,
            "title": "使用 Docker 仓库进行安装",
            "slug": "使用-docker-仓库进行安装",
            "children": []
          },
          {
            "level": 3,
            "title": "安装 Docker Engine-Community",
            "slug": "安装-docker-engine-community",
            "children": []
          },
          {
            "level": 3,
            "title": "启动 Docker",
            "slug": "启动-docker",
            "children": []
          },
          {
            "level": 3,
            "title": "卸载 docker",
            "slug": "卸载-docker",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "小知识",
        "slug": "小知识",
        "children": [
          {
            "level": 3,
            "title": "设置docker容器日志大小（全局设置）",
            "slug": "设置docker容器日志大小-全局设置",
            "children": []
          },
          {
            "level": 3,
            "title": "修改Docker数据⽬录位置，包含镜像位",
            "slug": "修改docker数据目录位置-包含镜像位",
            "children": []
          }
        ]
      }
    ],
    "path": "/blogs/linux/docker/docker-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Docker安装MySQL挂载外部配置文件和数据",
    "headers": [
      {
        "level": 2,
        "title": "docker拉取最新MySQL",
        "slug": "docker拉取最新mysql",
        "children": []
      },
      {
        "level": 2,
        "title": "启动docker，创建MySQL",
        "slug": "启动docker-创建mysql",
        "children": []
      },
      {
        "level": 2,
        "title": "docker拉取MySQL",
        "slug": "docker拉取mysql",
        "children": []
      },
      {
        "level": 2,
        "title": "创建配置文件",
        "slug": "创建配置文件",
        "children": []
      },
      {
        "level": 2,
        "title": "创建MySQL配置文件",
        "slug": "创建mysql配置文件",
        "children": []
      },
      {
        "level": 2,
        "title": "运行容器",
        "slug": "运行容器",
        "children": []
      }
    ],
    "path": "/blogs/linux/docker/mysql-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Docker安装并配置Nginx",
    "headers": [],
    "path": "/blogs/linux/docker/nginx-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Docker安装并配置Redis",
    "headers": [],
    "path": "/blogs/linux/docker/redis-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Linux 使用 Vsftpd 搭建 FTP 服务",
    "headers": [
      {
        "level": 2,
        "title": "FTP 的两种模式",
        "slug": "ftp-的两种模式",
        "children": [
          {
            "level": 3,
            "title": "主动模式",
            "slug": "主动模式",
            "children": []
          },
          {
            "level": 3,
            "title": "被动模式",
            "slug": "被动模式",
            "children": []
          },
          {
            "level": 3,
            "title": "两种模式比较",
            "slug": "两种模式比较",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "安装 Vsftpd",
        "slug": "安装-vsftpd",
        "children": []
      },
      {
        "level": 2,
        "title": "配置 Vsftpd",
        "slug": "配置-vsftpd",
        "children": []
      },
      {
        "level": 2,
        "title": "防火墙配置",
        "slug": "防火墙配置",
        "children": []
      },
      {
        "level": 2,
        "title": "文件目录说明",
        "slug": "文件目录说明",
        "children": []
      },
      {
        "level": 2,
        "title": "vsftpd.conf 配置说明",
        "slug": "vsftpd-conf-配置说明",
        "children": []
      },
      {
        "level": 2,
        "title": "常用命令",
        "slug": "常用命令",
        "children": []
      }
    ],
    "path": "/blogs/linux/ftp/ftp-install.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "Centos安装Jenkins",
    "headers": [
      {
        "level": 2,
        "title": "Jenkins介绍",
        "slug": "jenkins介绍",
        "children": []
      },
      {
        "level": 2,
        "title": "Jenkins的特征",
        "slug": "jenkins的特征",
        "children": []
      },
      {
        "level": 2,
        "title": "Jenkins安装",
        "slug": "jenkins安装",
        "children": [
          {
            "level": 3,
            "title": "yum安装",
            "slug": "yum安装",
            "children": []
          },
          {
            "level": 3,
            "title": "rmp安装(北京外国语大学开源软件镜像站)",
            "slug": "rmp安装-北京外国语大学开源软件镜像站",
            "children": []
          },
          {
            "level": 3,
            "title": "修改jenkins配置",
            "slug": "修改jenkins配置",
            "children": []
          },
          {
            "level": 3,
            "title": "踩坑",
            "slug": "踩坑",
            "children": []
          },
          {
            "level": 3,
            "title": "跳过插件安装",
            "slug": "跳过插件安装",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "Jenkins插件管理",
        "slug": "jenkins插件管理",
        "children": [
          {
            "level": 3,
            "title": "修改Jenkins插件下载地址",
            "slug": "修改jenkins插件下载地址",
            "children": []
          },
          {
            "level": 3,
            "title": "下载中文汉化插件",
            "slug": "下载中文汉化插件",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "Jenkins用户权限管理",
        "slug": "jenkins用户权限管理",
        "children": [
          {
            "level": 3,
            "title": "创建角色",
            "slug": "创建角色",
            "children": []
          },
          {
            "level": 3,
            "title": "创建用户",
            "slug": "创建用户",
            "children": []
          },
          {
            "level": 3,
            "title": "给用户分配角色",
            "slug": "给用户分配角色",
            "children": []
          },
          {
            "level": 3,
            "title": "创建项目测试权限",
            "slug": "创建项目测试权限",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "Jenkins凭证管理",
        "slug": "jenkins凭证管理",
        "children": [
          {
            "level": 3,
            "title": "安装Git插件和Git工具",
            "slug": "安装git插件和git工具",
            "children": []
          },
          {
            "level": 3,
            "title": "用户密码类型",
            "slug": "用户密码类型",
            "children": []
          },
          {
            "level": 3,
            "title": "SSH密钥类型",
            "slug": "ssh密钥类型",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "Maven安装和配置",
        "slug": "maven安装和配置",
        "children": [
          {
            "level": 3,
            "title": "安装Maven",
            "slug": "安装maven",
            "children": []
          },
          {
            "level": 3,
            "title": "配置环境变量",
            "slug": "配置环境变量",
            "children": []
          },
          {
            "level": 3,
            "title": "全局工具配置关联JDK和Maven",
            "slug": "全局工具配置关联jdk和maven",
            "children": []
          },
          {
            "level": 3,
            "title": "添加Jenkins全局变量",
            "slug": "添加jenkins全局变量",
            "children": []
          },
          {
            "level": 3,
            "title": "配置本地仓库地址和阿里镜像",
            "slug": "配置本地仓库地址和阿里镜像",
            "children": []
          }
        ]
      },
      {
        "level": 2,
        "title": "Jenkins构建Maven项目",
        "slug": "jenkins构建maven项目",
        "children": [
          {
            "level": 3,
            "title": "Jenkins构建的项目类型介绍",
            "slug": "jenkins构建的项目类型介绍",
            "children": []
          },
          {
            "level": 3,
            "title": "自由风格项目构建",
            "slug": "自由风格项目构建",
            "children": []
          }
        ]
      }
    ],
    "path": "/blogs/linux/jenkins/Jenkins.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/404.html",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/categories/linux/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/categories/hexo/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/tags/gitlab/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/tags/jenkins/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/tags/hexo/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/tags/docker/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/tags/ftp/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/timeline/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/posts/1/",
    "pathLocale": "/",
    "extraFields": []
  },
  {
    "title": "",
    "headers": [],
    "path": "/posts/2/",
    "pathLocale": "/",
    "extraFields": []
  }
]

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateSearchIndex) {
    __VUE_HMR_RUNTIME__.updateSearchIndex(searchIndex)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ searchIndex }) => {
    __VUE_HMR_RUNTIME__.updateSearchIndex(searchIndex)
  })
}
