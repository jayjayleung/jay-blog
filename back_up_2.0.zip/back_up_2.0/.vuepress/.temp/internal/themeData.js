export const themeData = {
  "style": "@vuepress-reco/style-default",
  "logo": "/logo.png",
  "author": "jayjay",
  "authorAvatar": "/avatar.png",
  "docsRepo": "https://github.com/vuepress-reco/vuepress-theme-reco-next",
  "docsBranch": "main",
  "docsDir": "example",
  "lastUpdatedText": "",
  "autoSetCategory": true,
  "series": {
    "/docs/hexo/": [
      {
        "text": "hexo",
        "children": [
          "hexoBuildBlog",
          "hexoScript"
        ]
      }
    ],
    "/blogs/linux/docker/": [
      {
        "text": "docker",
        "children": [
          {
            "text": "docker安装(centos7)",
            "link": "docker-install"
          },
          {
            "text": "docker安装mysql",
            "link": "mysql-install"
          },
          {
            "text": "docker安装redis",
            "link": "redis-install"
          },
          {
            "text": "docker安装nginx",
            "link": "nginx-install"
          }
        ]
      }
    ],
    "/blogs/linux/ftp/": [
      {
        "text": "ftp",
        "children": [
          {
            "text": "centos7安装ftp",
            "link": "ftp-install"
          }
        ]
      }
    ],
    "/blogs/linux/jenkins/": [
      {
        "text": "jenkins",
        "children": [
          {
            "text": "centos7安装ftp",
            "link": "jenkins"
          },
          {
            "text": "GitLab代码托管服务器安装",
            "link": "/blogs/linux/GitLab-install"
          }
        ]
      }
    ]
  },
  "navbar": [
    {
      "text": "Home",
      "link": "/"
    },
    {
      "text": "Categories",
      "link": "/categories/linux/1/"
    },
    {
      "text": "Tags",
      "link": "/tags/docker/1/"
    },
    {
      "text": "Docs",
      "children": [
        {
          "text": "hexo",
          "link": "/docs/hexo/hexoBuildBlog"
        },
        {
          "text": "linux",
          "children": [
            {
              "text": "docker",
              "link": "/blogs/linux/docker/docker-install"
            },
            {
              "text": "ftp",
              "link": "/blogs/linux/ftp/ftp-install"
            },
            {
              "text": "jenkins",
              "link": "/blogs/linux/jenkins/jenkins"
            }
          ]
        }
      ]
    },
    {
      "text": "掘金",
      "link": "https://juejin.cn/user/1583723129876158"
    },
    {
      "text": "Git",
      "children": [
        {
          "text": "GitHub",
          "link": "https://github.com/jayjayleung"
        },
        {
          "text": "Gitee",
          "link": "https://gitee.com/jayjay-coder"
        }
      ]
    }
  ],
  "valineConfig": {
    "appId": "NV4CrouQGO38orHsLqOvcJEq-gzGzoHsz",
    "appKey": "xAeSpWc67sRB1MKPR4vKxupg",
    "placeholder": "请留下你的痕迹~~",
    "verify": true,
    "recordIP": true
  }
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateThemeData) {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ themeData }) => {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  })
}
